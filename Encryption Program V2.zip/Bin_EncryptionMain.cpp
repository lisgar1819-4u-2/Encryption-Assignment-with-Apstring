/***************************************************

Bin (Quoc Dat Phung)
Teacher: Ms. Lindsay Cullum
Date: March 18, 2019

        Program that takes in input from the
        user and then encrypts it or decrypts
        it. It uses apstring.

TIME SPENT:
     - March 18 : 7 hours (debugging from old version)
     - March 19 : 2 hours (encryption and decryption)
     - March 20 : 2 hours (make them into functions
     - March 23 : 2 hours (functions into apstring.h***FAIL)
     - March 25 : 15 min (adding comments)
***************************************************/

#include <iostream>
using namespace std;

#include "apstring.h"
#include "apstring.cpp"
#include "apmatrix.h"
#include <fstream>


apstring removeNonAlphabet (apstring message);
apstring encryption(apstring keyword, apstring message,
                    const int numRows, const int numCols);
apstring decryption(apstring keyword, apstring message, apstring encrypted,
                    const int numRows, const int numCols);

int main () {

///Input
//Declaring Variables

    int numRows, numCols;// row and column
    apstring keyword;   //keyword
    apstring message;   // message waiting to be encrypted
    apstring encrypted; // encrypted message
    apstring decrypted; // decrypted message


//Opening in file
    ifstream file;
    file.open ("encode.dat");


//If file cannot open
    if (!file)
      {
          cout << "File not found" << endl;
          return 404;
      }

    cout << "This program takes in a message to encrypt/decrypt ";
    cout << "based on a keyword.\nIt also gets rid of invalid ";
    cout << "characters within the message\n " << endl;

//Taking in keyword and message from file
    getline(file, keyword);
    getline(file, message);

    cout << "Input from file:" << endl;
    cout << "Keyword: " << keyword << endl;
    cout << "Message: " << message << endl;

///Process and Calculation
    //removing non-alphabet characters;
    message = removeNonAlphabet(message);
    numCols = keyword.length();
    numRows = message.length()/numCols + 1;

    //This also removes the non-alphabet characters but does not work with apstring.
    //It works with strings only.
    /*
    message.erase(remove_if(message.begin(), message.end(), ::isspace), message.end());
    message.erase(remove_if(message.begin(), message.end(), ::ispunct), message.end());
    keyword.erase(remove_if(keyword.begin(), keyword.end(), ::isspace), keyword.end());
    keyword.erase(remove_if(keyword.begin(), keyword.end(), ::ispunct), keyword.end());
    */

    //encryption and decryption:
    encrypted = encryption(keyword, message, numRows, numCols);
    decrypted = decryption(keyword, message, encrypted, numRows, numCols);


///Output
    cout << endl << "Encrypted Message: ";
    cout << encrypted;

    cout << endl << "Decrypted Message: ";
    cout << decrypted << endl;



//Closing file
    file.close();

return 0;
}

apstring removeNonAlphabet(apstring message)
{
    int counter = 0;
    int i, j;

   for(i = 0; i < message.length(); i++) {
      // characters that are not from a to z will be eliminated
      while(!( (message[i] >= 'a' && message[i] <= 'z') ||
              (message[i] >= 'A' && message[i] <= 'Z')
              ))
      {
      //another for loop because...
      //the first few elements of the array
      //will be normal characters.
      //So j starts at the letter that's not
      //from a to z
         for(j = i; j < message.length()-1; j++) {
            message[j] = message[j+1];
         }
      //add counter to know how many elements
      //were eliminated.
         counter++;
      }
   }

   //after some characters are eliminated, the string
   //is going to be shorter. subtract length and counter
   //to get the actual size of the apstring.
   message = message.substr(0, message.length() - counter);
   counter = 0;


   return message;

}


apstring encryption(apstring keyword, apstring message,
                    const int numRows, const int numCols)
{

 apmatrix <char> cryptMatrix(numRows,numCols);
apstring crypto;


    for (int r = 0; r < numRows; r++)
    {

        for (int c = 0; c < numCols ; c++)
        {
            //imagine you have an apmatrix.
            //to access an element in it, use the rectangle formula
            //r*numCols. But the element of the array may be a few
            //indexes off so you add it to "c", which is the number
            //of elements wihin that column.
            ///Method: take the element within the keyword array, subtract
            ///"A" to get the difference and add it to the element in the
            ///message that we want to encrypt.
            //also this gives us a number and we convert it to a character.
             cryptMatrix[r][c] = char(keyword[c] -'A' + message[r*numCols+c]);
            //transfering matrix into apstring
             message[r*numCols+c] = cryptMatrix[r][c];
            //if our current element exceeds the size of the message array.
            if ((r*numCols+c) == message.length()-1)
             {
                 break;
             }

        }
    }
    //our message is encrypted and we pass it into a string before returning it.
    crypto = message;

    return crypto;
}

apstring decryption(apstring keyword, apstring message, apstring encrypted,
                    const int numRows, const int numCols)
{

 apmatrix <char> decryptMatrix(numRows,numCols);
apstring decrypto;


    for (int r = 0; r < numRows; r++)
    {

        for (int c = 0; c < numCols ; c++)
        {

            ///Same thing here but the method is reversed (undo encryption)
             decryptMatrix[r][c] = char(encrypted[r*numCols+c] - keyword[c] + 'A');
             message[r*numCols+c] = decryptMatrix[r][c];
            if ((r*numCols+c) == message.length()-1)
             {
                 break;
             }

        }
    }
    decrypto = message;

    return decrypto;
}



